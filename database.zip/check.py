import cv2
import face_recognition
import os


def check_in_bases(user_id):
